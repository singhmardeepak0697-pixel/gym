import { useState, useEffect } from "react";
import { FoodForm } from "./components/FoodForm";
import { WorkoutForm } from "./components/WorkoutForm";
import { SummaryPanel } from "./components/SummaryPanel";
import { FoodLogEntry, WorkoutEntry, DailyGoals, DailyStats, WorkoutHistory } from "./types";

const DEFAULT_GOALS: DailyGoals = {
  calories: 2100,
  protein: 160,
  carbs: 200,
  fat: 70,
};

function App() {
  const [foodLog, setFoodLog] = useState<FoodLogEntry[]>([]);
  const [workoutHistory, setWorkoutHistory] = useState<WorkoutHistory>({});
  const [dailyGoals, setDailyGoals] = useState<DailyGoals>(DEFAULT_GOALS);
  const [dailyStats, setDailyStats] = useState<DailyStats>({
    water: 0,
    steps: 0,
    sleep: 0,
  });

  // Load from localStorage on mount
  useEffect(() => {
    const savedFood = localStorage.getItem("fittrack_foodLog");
    const savedWorkouts = localStorage.getItem("fittrack_workouts");
    const savedGoals = localStorage.getItem("fittrack_goals");
    const savedStats = localStorage.getItem("fittrack_stats");

    if (savedFood) setFoodLog(JSON.parse(savedFood));
    if (savedWorkouts) setWorkoutHistory(JSON.parse(savedWorkouts));
    if (savedGoals) setDailyGoals(JSON.parse(savedGoals));
    if (savedStats) setDailyStats(JSON.parse(savedStats));
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("fittrack_foodLog", JSON.stringify(foodLog));
  }, [foodLog]);

  useEffect(() => {
    localStorage.setItem("fittrack_workouts", JSON.stringify(workoutHistory));
  }, [workoutHistory]);

  useEffect(() => {
    localStorage.setItem("fittrack_goals", JSON.stringify(dailyGoals));
  }, [dailyGoals]);

  useEffect(() => {
    localStorage.setItem("fittrack_stats", JSON.stringify(dailyStats));
  }, [dailyStats]);

  const handleAddFood = (entry: FoodLogEntry) => {
    setFoodLog([...foodLog, entry]);
  };

  const handleRemoveFood = (id: string) => {
    setFoodLog(foodLog.filter((entry) => entry.id !== id));
  };

  const handleAddWorkout = (entry: WorkoutEntry) => {
    setWorkoutHistory((prev) => ({
      ...prev,
      [entry.exercise]: [entry, ...(prev[entry.exercise] || [])],
    }));
  };

  const handleUpdateStats = (stats: Partial<DailyStats>) => {
    setDailyStats((prev) => ({ ...prev, ...stats }));
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 mb-2">
            FitTrack
          </h1>
          <p className="text-gray-400">Your personal fitness coach</p>
        </header>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <FoodForm
            foodLog={foodLog}
            onAddFood={handleAddFood}
            onRemoveFood={handleRemoveFood}
            dailyGoals={dailyGoals}
          />
          <WorkoutForm
            workoutHistory={workoutHistory}
            onAddWorkout={handleAddWorkout}
          />
        </div>

        {/* Summary Panel */}
        <SummaryPanel
          foodLog={foodLog}
          dailyGoals={dailyGoals}
          dailyStats={dailyStats}
          onUpdateStats={handleUpdateStats}
          workoutHistory={workoutHistory}
        />
      </div>
    </div>
  );
}

export default App;