export interface FoodItem {
  name: string;
  per100g: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
  };
  defaultPortion: number;
  defaultUnit: string;
}

export interface FoodLogEntry {
  id: string;
  foodName: string;
  quantity: number;
  unit: string;
  macros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
  };
  timestamp: number;
}

export interface WorkoutEntry {
  id: string;
  exercise: string;
  sets: number;
  reps: number;
  weight: number;
  muscleGroup: string;
  caloriesBurned: number;
  timestamp: number;
}

export interface DailyGoals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface DailyStats {
  water: number;
  steps: number;
  sleep: number;
}

export interface WorkoutHistory {
  [exercise: string]: WorkoutEntry[];
}