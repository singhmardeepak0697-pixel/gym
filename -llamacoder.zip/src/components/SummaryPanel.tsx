import { Droplets, Footprints, Moon, CheckCircle, XCircle, TrendingUp } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { FoodLogEntry, DailyGoals, DailyStats, WorkoutHistory } from "../types";
import { format, subDays } from "date-fns";

interface SummaryPanelProps {
  foodLog: FoodLogEntry[];
  dailyGoals: DailyGoals;
  dailyStats: DailyStats;
  onUpdateStats: (stats: Partial<DailyStats>) => void;
  workoutHistory: WorkoutHistory;
}

export function SummaryPanel({
  foodLog,
  dailyGoals,
  dailyStats,
  onUpdateStats,
  workoutHistory,
}: SummaryPanelProps) {
  const totals = foodLog.reduce(
    (acc, entry) => ({
      calories: acc.calories + entry.macros.calories,
      protein: acc.protein + entry.macros.protein,
      carbs: acc.carbs + entry.macros.carbs,
      fat: acc.fat + entry.macros.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const todayWorkouts = Object.values(workoutHistory).flat().filter(
    w => format(w.timestamp, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")
  );

  const hasWorkoutToday = todayWorkouts.length > 0;

  const getCoachTip = () => {
    const proteinRemaining = dailyGoals.protein - totals.protein;
    const caloriesRemaining = dailyGoals.calories - totals.calories;

    if (proteinRemaining > 20) {
      return `You're ${proteinRemaining}g short on protein — add a scoop of whey post-workout.`;
    }
    if (caloriesRemaining > 500 && totals.protein >= dailyGoals.protein) {
      return `Great protein intake! Add some healthy fats to hit your calorie goal.`;
    }
    if (!hasWorkoutToday) {
      return `No workout logged yet. Remember: consistency beats intensity.`;
    }
    if (dailyStats.water < 6) {
      return `Hydration alert! Aim for 8+ cups of water for optimal recovery.`;
    }
    if (dailyStats.sleep < 7) {
      return `Sleep dropped to ${dailyStats.sleep}h — aim for 7+ to recover muscle.`;
    }
    return "You're crushing it! Keep showing up and the results will follow.";
  };

  const getWeeklyReview = () => {
    const sevenDaysAgo = subDays(new Date(), 7);
    const weekWorkouts = Object.values(workoutHistory).flat().filter(
      w => w.timestamp >= sevenDaysAgo.getTime()
    );

    if (weekWorkouts.length === 0) return null;

    const exerciseGroups = weekWorkouts.reduce((acc, w) => {
      if (!acc[w.exercise]) acc[w.exercise] = [];
      acc[w.exercise].push(w);
      return acc;
    }, {} as Record<string, typeof weekWorkouts>);

    const strengthGains = Object.entries(exerciseGroups)
      .map(([exercise, workouts]) => {
        if (workouts.length < 2) return null;
        const first = workouts[workouts.length - 1];
        const last = workouts[0];
        if (last.weight > first.weight) {
          const percent = ((last.weight - first.weight) / first.weight * 100).toFixed(0);
          return `${exercise}: ${first.weight}kg → ${last.weight}kg (+${percent}%)`;
        }
        return null;
      })
      .filter(Boolean) as string[];

    return {
      totalWorkouts: weekWorkouts.length,
      strengthGains,
    };
  };

  const weeklyReview = getWeeklyReview();

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardContent className="pt-6 space-y-4">
        {/* Daily Progress */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gray-900 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400">Calories</span>
              {totals.calories >= dailyGoals.calories ? (
                <CheckCircle className="w-4 h-4 text-green-400" />
              ) : (
                <XCircle className="w-4 h-4 text-red-400" />
              )}
            </div>
            <div className="text-white font-semibold">
              {totals.calories} / {dailyGoals.calories}
            </div>
          </div>

          <div className="bg-gray-900 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400">Protein</span>
              {totals.protein >= dailyGoals.protein ? (
                <CheckCircle className="w-4 h-4 text-green-400" />
              ) : (
                <XCircle className="w-4 h-4 text-red-400" />
              )}
            </div>
            <div className="text-white font-semibold">
              {totals.protein}g / {dailyGoals.protein}g
            </div>
          </div>

          <div className="bg-gray-900 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400">Workout</span>
              {hasWorkoutToday ? (
                <CheckCircle className="w-4 h-4 text-green-400" />
              ) : (
                <XCircle className="w-4 h-4 text-red-400" />
              )}
            </div>
            <div className="text-white font-semibold">
              {hasWorkoutToday ? "✅ Done" : "❌ Pending"}
            </div>
          </div>

          <div className="bg-gray-900 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400">Water</span>
              <Droplets className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-white font-semibold">
              {dailyStats.water} / 8 cups
            </div>
          </div>
        </div>

        {/* Daily Stats Input */}
        <div className="grid grid-cols-3 gap-2">
          <div className="space-y-1">
            <Label className="text-xs text-gray-400">Water</Label>
            <Input
              type="number"
              value={dailyStats.water || ""}
              onChange={(e) => onUpdateStats({ water: parseInt(e.target.value) || 0 })}
              className="bg-gray-700 border-gray-600 text-white h-8"
              min="0"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs text-gray-400">Steps (k)</Label>
            <Input
              type="number"
              value={dailyStats.steps || ""}
              onChange={(e) => onUpdateStats({ steps: parseInt(e.target.value) || 0 })}
              className="bg-gray-700 border-gray-600 text-white h-8"
              min="0"
              step="0.1"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs text-gray-400">Sleep (h)</Label>
            <Input
              type="number"
              value={dailyStats.sleep || ""}
              onChange={(e) => onUpdateStats({ sleep: parseInt(e.target.value) || 0 })}
              className="bg-gray-700 border-gray-600 text-white h-8"
              min="0"
              max="24"
              step="0.5"
            />
          </div>
        </div>

        {/* Coach Tip */}
        <div className="bg-blue-900/30 border border-blue-700 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <TrendingUp className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-blue-200">{getCoachTip()}</p>
          </div>
        </div>

        {/* Weekly Review */}
        {weeklyReview && weeklyReview.totalWorkouts > 0 && (
          <div className="bg-purple-900/30 border border-purple-700 rounded-lg p-3">
            <div className="text-xs text-purple-400 font-semibold mb-2">
              📊 Weekly Review ({weeklyReview.totalWorkouts} workouts)
            </div>
            {weeklyReview.strengthGains.length > 0 ? (
              <div className="space-y-1">
                {weeklyReview.strengthGains.map((gain, i) => (
                  <div key={i} className="text-xs text-purple-200">
                    {gain}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-xs text-purple-200">
                Keep logging! Track your lifts to see strength gains.
              </div>
            )}
          </div>
        )}

        {/* Motivation */}
        <div className="text-center">
          <p className="text-xs text-gray-500 italic">
            "Consistency beats intensity. Keep showing up."
          </p>
        </div>
      </CardContent>
    </Card>
  );
}