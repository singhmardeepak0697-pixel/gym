import { useState } from "react";
import { Utensils, Plus, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { FOOD_DATABASE } from "../utils/FoodDatabase";
import { FoodLogEntry, DailyGoals } from "../types";

interface FoodFormProps {
  foodLog: FoodLogEntry[];
  onAddFood: (entry: FoodLogEntry) => void;
  onRemoveFood: (id: string) => void;
  dailyGoals: DailyGoals;
}

export function FoodForm({ foodLog, onAddFood, onRemoveFood, dailyGoals }: FoodFormProps) {
  const [selectedFood, setSelectedFood] = useState<string>("");
  const [quantity, setQuantity] = useState<string>("");

  const selectedFoodData = FOOD_DATABASE.find((f) => f.name === selectedFood);

  const calculateMacros = (foodName: string, qty: number) => {
    const food = FOOD_DATABASE.find((f) => f.name === foodName);
    if (!food) return null;

    const multiplier = qty / food.defaultPortion;
    return {
      calories: Math.round(food.per100g.calories * (qty / 100)),
      protein: Math.round(food.per100g.protein * (qty / 100)),
      carbs: Math.round(food.per100g.carbs * (qty / 100)),
      fat: Math.round(food.per100g.fat * (qty / 100)),
      fiber: Math.round(food.per100g.fiber * (qty / 100)),
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFood || !quantity) return;

    const macros = calculateMacros(selectedFood, parseFloat(quantity));
    if (!macros) return;

    const foodData = FOOD_DATABASE.find((f) => f.name === selectedFood)!;
    
    onAddFood({
      id: Date.now().toString(),
      foodName: selectedFood,
      quantity: parseFloat(quantity),
      unit: foodData.defaultUnit,
      macros,
      timestamp: Date.now(),
    });

    setSelectedFood("");
    setQuantity("");
  };

  const totals = foodLog.reduce(
    (acc, entry) => ({
      calories: acc.calories + entry.macros.calories,
      protein: acc.protein + entry.macros.protein,
      carbs: acc.carbs + entry.macros.carbs,
      fat: acc.fat + entry.macros.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Utensils className="w-5 h-5 text-green-400" />
          Food Log
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-gray-300">Select Food</Label>
            <Select value={selectedFood} onValueChange={setSelectedFood}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Choose a food..." />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                {FOOD_DATABASE.map((food) => (
                  <SelectItem key={food.name} value={food.name} className="text-white">
                    {food.name} ({food.defaultPortion}{food.defaultUnit})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">
              Quantity ({selectedFoodData?.defaultUnit || "g"})
            </Label>
            <Input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder={selectedFoodData?.defaultPortion.toString() || "100"}
              className="bg-gray-700 border-gray-600 text-white"
              min="0"
              step="0.1"
            />
          </div>

          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Add to Daily Log
          </Button>
        </form>

        {/* Daily Totals */}
        <div className="bg-gray-900 rounded-lg p-4 space-y-2">
          <h3 className="text-sm font-semibold text-gray-400">Daily Totals</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-white">
              Calories: <span className="text-green-400">{totals.calories}</span> / {dailyGoals.calories}
            </div>
            <div className="text-white">
              Protein: <span className="text-green-400">{totals.protein}g</span> / {dailyGoals.protein}g
            </div>
            <div className="text-white">
              Carbs: <span className="text-blue-400">{totals.carbs}g</span> / {dailyGoals.carbs}g
            </div>
            <div className="text-white">
              Fat: <span className="text-yellow-400">{totals.fat}g</span> / {dailyGoals.fat}g
            </div>
          </div>
          <div className="text-xs text-gray-500 pt-2 border-t border-gray-700">
            Calories left: {Math.max(0, dailyGoals.calories - totals.calories)} | 
            Protein left: {Math.max(0, dailyGoals.protein - totals.protein)}g
          </div>
        </div>

        {/* Food Log List */}
        {foodLog.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-400">Today's Foods</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {foodLog.map((entry) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between bg-gray-700 rounded-lg p-3"
                >
                  <div>
                    <div className="text-white text-sm font-medium">{entry.foodName}</div>
                    <div className="text-xs text-gray-400">
                      {entry.quantity}{entry.unit} • {entry.macros.calories} cal • {entry.macros.protein}g protein
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onRemoveFood(entry.id)}
                    className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}