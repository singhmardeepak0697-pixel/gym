import { useState } from "react";
import { Dumbbell, Plus, TrendingUp } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { EXERCISES, MUSCLE_GROUPS } from "../utils/FoodDatabase";
import { WorkoutEntry, WorkoutHistory } from "../types";
import { format } from "date-fns";

interface WorkoutFormProps {
  workoutHistory: WorkoutHistory;
  onAddWorkout: (entry: WorkoutEntry) => void;
}

export function WorkoutForm({ workoutHistory, onAddWorkout }: WorkoutFormProps) {
  const [exercise, setExercise] = useState<string>("");
  const [sets, setSets] = useState<string>("");
  const [reps, setReps] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [muscleGroup, setMuscleGroup] = useState<string>("");

  const getLastWorkout = (exerciseName: string) => {
    const history = workoutHistory[exerciseName] || [];
    return history.length > 0 ? history[0] : null;
  };

  const getProgressSuggestion = (exerciseName: string) => {
    const last = getLastWorkout(exerciseName);
    if (!last) return "First time logging this exercise. Start conservative!";

    const currentWeight = parseFloat(weight) || 0;
    const currentReps = parseFloat(reps) || 0;
    const currentSets = parseFloat(sets) || 0;

    if (currentWeight > last.weight) {
      return `🔥 Strong! You increased weight by ${(currentWeight - last.weight).toFixed(1)}kg`;
    } else if (currentReps > last.reps) {
      return `💪 Great job! You added ${currentReps - last.reps} reps`;
    } else if (currentSets > last.sets) {
      return `📈 Progress! You added ${currentSets - last.sets} sets`;
    } else if (currentWeight === last.weight && currentReps === last.reps) {
      return `🎯 Same as last session. Try adding 2.5kg or 1 rep next time!`;
    } else {
      return `💡 Suggestion: Increase weight by 2.5kg or add 1 rep per set`;
    }
  };

  const calculateCaloriesBurned = (weight: number, reps: number, sets: number) => {
    return Math.round(weight * reps * sets * 0.05);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!exercise || !sets || !reps || !weight || !muscleGroup) return;

    const weightNum = parseFloat(weight);
    const repsNum = parseFloat(reps);
    const setsNum = parseFloat(sets);

    onAddWorkout({
      id: Date.now().toString(),
      exercise,
      sets: setsNum,
      reps: repsNum,
      weight: weightNum,
      muscleGroup,
      caloriesBurned: calculateCaloriesBurned(weightNum, repsNum, setsNum),
      timestamp: Date.now(),
    });

    setExercise("");
    setSets("");
    setReps("");
    setWeight("");
    setMuscleGroup("");
  };

  const lastWorkout = exercise ? getLastWorkout(exercise) : null;
  const suggestion = exercise && sets && reps && weight ? getProgressSuggestion(exercise) : null;

  const todayWorkouts = Object.values(workoutHistory).flat().filter(
    w => format(w.timestamp, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")
  );

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Dumbbell className="w-5 h-5 text-green-400" />
          Workout Log
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-gray-300">Exercise</Label>
            <Select value={exercise} onValueChange={setExercise}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select exercise..." />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                {EXERCISES.map((ex) => (
                  <SelectItem key={ex} value={ex} className="text-white">
                    {ex}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-2">
              <Label className="text-gray-300">Sets</Label>
              <Input
                type="number"
                value={sets}
                onChange={(e) => setSets(e.target.value)}
                placeholder="3"
                className="bg-gray-700 border-gray-600 text-white"
                min="1"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300">Reps</Label>
              <Input
                type="number"
                value={reps}
                onChange={(e) => setReps(e.target.value)}
                placeholder="10"
                className="bg-gray-700 border-gray-600 text-white"
                min="1"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300">Weight (kg)</Label>
              <Input
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="60"
                className="bg-gray-700 border-gray-600 text-white"
                min="0"
                step="0.5"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">Muscle Group</Label>
            <Select value={muscleGroup} onValueChange={setMuscleGroup}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select muscle group..." />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                {MUSCLE_GROUPS.map((group) => (
                  <SelectItem key={group} value={group} className="text-white">
                    {group}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {lastWorkout && (
            <div className="bg-gray-900 rounded-lg p-3 text-sm">
              <div className="text-gray-400 mb-1">Last session:</div>
              <div className="text-white">
                {lastWorkout.sets}×{lastWorkout.reps} @ {lastWorkout.weight}kg
              </div>
            </div>
          )}

          {suggestion && (
            <div className="bg-green-900/30 border border-green-700 rounded-lg p-3 text-sm">
              <div className="flex items-start gap-2 text-green-300">
                <TrendingUp className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>{suggestion}</span>
              </div>
            </div>
          )}

          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Log Workout
          </Button>
        </form>

        {/* Today's Workouts */}
        {todayWorkouts.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-400">Today's Workouts</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {todayWorkouts.map((workout) => (
                <div key={workout.id} className="bg-gray-700 rounded-lg p-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-white text-sm font-medium">{workout.exercise}</div>
                      <div className="text-xs text-gray-400">
                        {workout.sets}×{workout.reps} @ {workout.weight}kg • {workout.muscleGroup}
                      </div>
                    </div>
                    <div className="text-xs text-orange-400">
                      ~{workout.caloriesBurned} kcal
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}