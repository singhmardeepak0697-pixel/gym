import { FoodItem } from "../types";

export const FOOD_DATABASE: FoodItem[] = [
  // Proteins
  { name: "Chicken Breast", per100g: { calories: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Egg", per100g: { calories: 155, protein: 13, carbs: 1.1, fat: 11, fiber: 0 }, defaultPortion: 1, defaultUnit: "piece" },
  { name: "Whey Protein", per100g: { calories: 360, protein: 75, carbs: 10, fat: 3, fiber: 0 }, defaultPortion: 30, defaultUnit: "g" },
  { name: "Salmon", per100g: { calories: 208, protein: 20, carbs: 0, fat: 13, fiber: 0 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Ground Beef (Lean)", per100g: { calories: 250, protein: 26, carbs: 0, fat: 15, fiber: 0 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Tuna (Canned)", per100g: { calories: 116, protein: 26, carbs: 0, fat: 1, fiber: 0 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Greek Yogurt", per100g: { calories: 59, protein: 10, carbs: 3.6, fat: 0.4, fiber: 0 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Cottage Cheese", per100g: { calories: 98, protein: 11, carbs: 3.4, fat: 4.3, fiber: 0 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Tofu", per100g: { calories: 76, protein: 8, carbs: 1.9, fat: 4.8, fiber: 0.3 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Lentils", per100g: { calories: 116, protein: 9, carbs: 20, fat: 0.4, fiber: 8 }, defaultPortion: 100, defaultUnit: "g" },
  
  // Carbs
  { name: "White Rice", per100g: { calories: 130, protein: 2.7, carbs: 28, fat: 0.3, fiber: 0.4 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Brown Rice", per100g: { calories: 111, protein: 2.6, carbs: 23, fat: 0.9, fiber: 1.8 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Oats", per100g: { calories: 389, protein: 16.9, carbs: 66, fat: 6.9, fiber: 10.6 }, defaultPortion: 50, defaultUnit: "g" },
  { name: "Sweet Potato", per100g: { calories: 86, protein: 1.6, carbs: 20, fat: 0.1, fiber: 3 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Whole Wheat Bread", per100g: { calories: 247, protein: 13, carbs: 41, fat: 3.4, fiber: 6 }, defaultPortion: 1, defaultUnit: "slice" },
  { name: "Pasta", per100g: { calories: 131, protein: 5, carbs: 25, fat: 1.1, fiber: 1.5 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Quinoa", per100g: { calories: 120, protein: 4.4, carbs: 21, fat: 1.9, fiber: 2.8 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Banana", per100g: { calories: 89, protein: 1.1, carbs: 23, fat: 0.3, fiber: 2.6 }, defaultPortion: 1, defaultUnit: "piece" },
  { name: "Apple", per100g: { calories: 52, protein: 0.3, carbs: 14, fat: 0.2, fiber: 2.4 }, defaultPortion: 1, defaultUnit: "piece" },
  { name: "Roti/Chapati", per100g: { calories: 104, protein: 3, carbs: 17, fat: 3, fiber: 2 }, defaultPortion: 1, defaultUnit: "piece" },
  
  // Fats
  { name: "Peanut Butter", per100g: { calories: 588, protein: 25, carbs: 20, fat: 50, fiber: 6 }, defaultPortion: 20, defaultUnit: "g" },
  { name: "Almonds", per100g: { calories: 579, protein: 21, carbs: 22, fat: 50, fiber: 12 }, defaultPortion: 30, defaultUnit: "g" },
  { name: "Avocado", per100g: { calories: 160, protein: 2, carbs: 9, fat: 15, fiber: 7 }, defaultPortion: 100, defaultUnit: "g" },
  { name: "Olive Oil", per100g: { calories: 884, protein: 0, carbs: 0, fat: 100, fiber: 0 }, defaultPortion: 15, defaultUnit: "ml" },
  { name: "Cheese", per100g: { calories: 402, protein: 25, carbs: 1.3, fat: 33, fiber: 0 }, defaultPortion: 30, defaultUnit: "g" },
  { name: "Butter", per100g: { calories: 717, protein: 0.9, carbs: 0.1, fat: 81, fiber: 0 }, defaultPortion: 10, defaultUnit: "g" },
  
  // Mixed Meals
  { name: "Protein Bar", per100g: { calories: 350, protein: 25, carbs: 30, fat: 12, fiber: 5 }, defaultPortion: 1, defaultUnit: "piece" },
  { name: "Smoothie Bowl", per100g: { calories: 180, protein: 6, carbs: 30, fat: 5, fiber: 4 }, defaultPortion: 300, defaultUnit: "g" },
  { name: "Burrito Bowl", per100g: { calories: 200, protein: 12, carbs: 25, fat: 7, fiber: 4 }, defaultPortion: 350, defaultUnit: "g" },
  { name: "Stir Fry", per100g: { calories: 150, protein: 15, carbs: 12, fat: 6, fiber: 3 }, defaultPortion: 300, defaultUnit: "g" },
  { name: "Protein Pancakes", per100g: { calories: 220, protein: 18, carbs: 25, fat: 5, fiber: 2 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Overnight Oats", per100g: { calories: 180, protein: 8, carbs: 28, fat: 4, fiber: 4 }, defaultPortion: 200, defaultUnit: "g" },
  { name: "Chicken Salad", per100g: { calories: 120, protein: 15, carbs: 8, fat: 4, fiber: 3 }, defaultPortion: 250, defaultUnit: "g" },
  { name: "Beef Stir Fry", per100g: { calories: 180, protein: 18, carbs: 10, fat: 8, fiber: 2 }, defaultPortion: 300, defaultUnit: "g" },
  { name: "Egg Omelette", per100g: { calories: 200, protein: 14, carbs: 3, fat: 15, fiber: 0 }, defaultPortion: 150, defaultUnit: "g" },
  { name: "Fish Curry", per100g: { calories: 160, protein: 18, carbs: 8, fat: 7, fiber: 2 }, defaultPortion: 250, defaultUnit: "g" },
];

export const EXERCISES = [
  "Squat", "Bench Press", "Deadlift", "Pull-ups", "Shoulder Press",
  "Barbell Row", "Lunges", "Bicep Curls", "Tricep Dips", "Leg Press",
  "Lat Pulldown", "Chest Fly", "Leg Curl", "Calf Raises", "Plank"
];

export const MUSCLE_GROUPS = ["Legs", "Chest", "Back", "Shoulders", "Arms", "Core"];